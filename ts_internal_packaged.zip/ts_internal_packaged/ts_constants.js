module.exports = {
    INCOMING_CASES_QUERY: 'http://www.prf.nll.mybluehost.me/wp-json/my-route/case-details-for-queue?test_key=0Wbjj49mZtRZ5YtcShGaIb10JbdNxEtezdZi2eios4w0TDcxPjRC',
    CONSTANTS_POST_ENDPOINT: 'http://www.prf.nll.mybluehost.me/wp-json/my-route/set-constant',
}